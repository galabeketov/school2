import styled from "styled-components";

const LayoutWrapper = styled.section``;

export default LayoutWrapper;
