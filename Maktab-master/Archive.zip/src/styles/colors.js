const colors = {
  mainBgColor: "#f1f5f9",
};

export default colors;
